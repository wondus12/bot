from http.server import HTTPServer, SimpleHTTPRequestHandler
import os
import webbrowser

def run(server_class=HTTPServer, handler_class=SimpleHTTPRequestHandler, port=8000):
    web_dir = os.path.join(os.path.dirname(__file__), 'web')
    os.chdir(web_dir)
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Starting web server on port {port}")
    print(f"Open http://localhost:{port}/device_registration.html in your browser")
    webbrowser.open(f'http://localhost:{port}/device_registration.html')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
